#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容，即使Magisk在未来改变了它的挂载点
MODDIR=${0%/*}

# 这个脚本将以 late_start service 模式执行
# 更多信息请访问 Magisk 主题

# wait for boot animation stopped
until [ "`getprop init.svc.bootanim`" = "stopped" ]
do
sleep 10
done

function set_value()                                        {
        if [ -f $2 ]; then
		echo $1 > $2
        fi
}

function lock_value()
{
        if [ -f $2 ]; then
                # chown 0.0 $2
                chmod 0666 $2
                echo $1 > $2
                chmod 0444 $2
        fi
}

lock_value 2169000 /sys/devices/system/cpu/cpu0/cpufreq/schedutil/scaling_max_freq
lock_value 1420000 /sys/devices/system/cpu/cpu4/cpufreq/schedutil/scaling_max_freq

set_value simple_ondemand /sys/class/kgsl/kgsl-3d0/devfreq/governor

echo "done"

