#!/system/bin/sh
# Project WIPE v2 https://github.com/yc9559/wipe-v2
# Author: yc9559
# Platform: e8890
# Generated at: 2019-05-25 15:53:51

CUR_LEVEL_FILE="/dev/.wipe_cur_level"
PARAM_BAK_FILE="/dev/.wipe_param_bak"

# const variables
PARAM_NUM=35

# sysfs_objx example:
# sysfs_obj1="${C0_GOVERNOR_DIR}/target_loads"
SCHED_DIR="/proc/sys/kernel/hmp"
C0_GOVERNOR_DIR="/sys/devices/system/cpu/cpu0/cpufreq/interactive"
C1_GOVERNOR_DIR="/sys/devices/system/cpu/cpu4/cpufreq/interactive"
C0_DIR="/sys/devices/system/cpu/cpu0"
C1_DIR="/sys/devices/system/cpu/cpu4"

sysfs_obj1="/sys/power/cpuhotplug/enabled"
sysfs_obj2="/sys/devices/system/cpu/cpuhotplug/enabled"
sysfs_obj3="${C0_DIR}/online"
sysfs_obj4="${C0_DIR}/cpufreq/scaling_governor"
sysfs_obj5="${C0_DIR}/cpufreq/scaling_min_freq"
sysfs_obj6="${C0_DIR}/cpufreq/scaling_max_freq"
sysfs_obj7="${C0_GOVERNOR_DIR}/hispeed_freq"
sysfs_obj8="${C0_GOVERNOR_DIR}/go_hispeed_load"
sysfs_obj9="${C0_GOVERNOR_DIR}/min_sample_time"
sysfs_obj10="${C0_GOVERNOR_DIR}/max_freq_hysteresis"
sysfs_obj11="${C0_GOVERNOR_DIR}/above_hispeed_delay"
sysfs_obj12="${C0_GOVERNOR_DIR}/target_loads"
sysfs_obj13="${C0_GOVERNOR_DIR}/timer_rate"
sysfs_obj14="${C0_GOVERNOR_DIR}/timer_slack"
sysfs_obj15="${C0_GOVERNOR_DIR}/boost"
sysfs_obj16="${C0_GOVERNOR_DIR}/boostpulse_duration"
sysfs_obj17="${C1_DIR}/online"
sysfs_obj18="${C1_DIR}/cpufreq/scaling_governor"
sysfs_obj19="${C1_DIR}/cpufreq/scaling_min_freq"
sysfs_obj20="${C1_DIR}/cpufreq/scaling_max_freq"
sysfs_obj21="${C1_GOVERNOR_DIR}/hispeed_freq"
sysfs_obj22="${C1_GOVERNOR_DIR}/go_hispeed_load"
sysfs_obj23="${C1_GOVERNOR_DIR}/min_sample_time"
sysfs_obj24="${C1_GOVERNOR_DIR}/max_freq_hysteresis"
sysfs_obj25="${C1_GOVERNOR_DIR}/above_hispeed_delay"
sysfs_obj26="${C1_GOVERNOR_DIR}/target_loads"
sysfs_obj27="${C1_GOVERNOR_DIR}/timer_rate"
sysfs_obj28="${C1_GOVERNOR_DIR}/timer_slack"
sysfs_obj29="${C1_GOVERNOR_DIR}/boost"
sysfs_obj30="${C1_GOVERNOR_DIR}/boostpulse_duration"
sysfs_obj31="${SCHED_DIR}/down_threshold"
sysfs_obj32="${SCHED_DIR}/up_threshold"
sysfs_obj33="${SCHED_DIR}/down_threshold"
sysfs_obj34="${SCHED_DIR}/load_avg_period_ms"
sysfs_obj35="${SCHED_DIR}/boost"


# level x example:
# lag percent: 90.0%
# battery life: 110.0%
# levelx_val1="38000"
# levelx_val2="85 1190000:90"

# LEVEL 0
# lag percent: 20.2%
# battery life: 110.6%
level0_val1="0"
level0_val2="0"
level0_val3="1"
level0_val4="interactive"
level0_val5="441000"
level0_val6="1587000"
level0_val7="1482000"
level0_val8="73"
level0_val9="18000"
level0_val10="178000"
level0_val11="58000"
level0_val12="47 546000:59 754000:23 858000:50 962000:25 1066000:57 1170000:64 1274000:88 1378000:54 1482000:72 1586000:80"
level0_val13="20000"
level0_val14="12345678"
level0_val15="0"
level0_val16="0"
level0_val17="1"
level0_val18="interactive"
level0_val19="727000"
level0_val20="2601000"
level0_val21="1872000"
level0_val22="65"
level0_val23="18000"
level0_val24="98000"
level0_val25="198000 2080000:178000 2184000:118000 2288000:198000 2392000:118000 2496000:58000"
level0_val26="19 832000:6 936000:37 1040000:88 1144000:98 1248000:80 1352000:49 1456000:88 1560000:79 1664000:80 1768000:66 1872000:98 1976000:99 2080000:98 2392000:97 2496000:53 2600000:96"
level0_val27="20000"
level0_val28="12345678"
level0_val29="0"
level0_val30="0"
level0_val31="607"
level0_val32="621"
level0_val33="607"
level0_val34="128"
level0_val35="0"

# LEVEL 1
# lag percent: 14.7%
# battery life: 106.6%
level1_val1="0"
level1_val2="0"
level1_val3="1"
level1_val4="interactive"
level1_val5="441000"
level1_val6="1587000"
level1_val7="1378000"
level1_val8="92"
level1_val9="18000"
level1_val10="158000"
level1_val11="158000 1482000:118000"
level1_val12="64 546000:34 858000:31 962000:77 1066000:67 1170000:57 1274000:97 1378000:67 1482000:3 1586000:48"
level1_val13="20000"
level1_val14="12345678"
level1_val15="0"
level1_val16="0"
level1_val17="1"
level1_val18="interactive"
level1_val19="727000"
level1_val20="2601000"
level1_val21="1872000"
level1_val22="61"
level1_val23="18000"
level1_val24="18000"
level1_val25="198000 2080000:178000 2184000:138000 2288000:198000 2392000:118000 2496000:58000"
level1_val26="17 832000:22 936000:11 1040000:78 1144000:17 1248000:82 1352000:42 1456000:93 1560000:79 1664000:80 1768000:76 1872000:99 2080000:98 2184000:97 2288000:98 2392000:86 2496000:83 2600000:97"
level1_val27="20000"
level1_val28="12345678"
level1_val29="0"
level1_val30="0"
level1_val31="590"
level1_val32="590"
level1_val33="590"
level1_val34="128"
level1_val35="1"

# LEVEL 2
# lag percent: 29.8%
# battery life: 116.3%
level2_val1="0"
level2_val2="0"
level2_val3="1"
level2_val4="interactive"
level2_val5="441000"
level2_val6="1587000"
level2_val7="1482000"
level2_val8="69"
level2_val9="18000"
level2_val10="58000"
level2_val11="18000"
level2_val12="39 546000:57 754000:7 858000:29 962000:61 1066000:59 1170000:57 1274000:75 1378000:48 1482000:63 1586000:57"
level2_val13="20000"
level2_val14="12345678"
level2_val15="0"
level2_val16="0"
level2_val17="1"
level2_val18="interactive"
level2_val19="727000"
level2_val20="2601000"
level2_val21="1872000"
level2_val22="66"
level2_val23="18000"
level2_val24="98000"
level2_val25="198000 2184000:158000 2288000:118000 2392000:98000"
level2_val26="56 832000:64 936000:83 1040000:86 1144000:90 1248000:80 1352000:93 1456000:89 1560000:37 1664000:72 1768000:44 1872000:98 1976000:99 2080000:98 2184000:96 2288000:98 2392000:84 2496000:75 2600000:19"
level2_val27="20000"
level2_val28="12345678"
level2_val29="0"
level2_val30="0"
level2_val31="649"
level2_val32="668"
level2_val33="649"
level2_val34="128"
level2_val35="0"

# LEVEL 3
# lag percent: 50.0%
# battery life: 125.7%
level3_val1="0"
level3_val2="0"
level3_val3="1"
level3_val4="interactive"
level3_val5="441000"
level3_val6="1587000"
level3_val7="1482000"
level3_val8="65"
level3_val9="18000"
level3_val10="98000"
level3_val11="18000"
level3_val12="45 546000:23 754000:14 858000:10 962000:79 1066000:27 1170000:33 1274000:31 1378000:53 1482000:71 1586000:80"
level3_val13="20000"
level3_val14="12345678"
level3_val15="0"
level3_val16="0"
level3_val17="1"
level3_val18="interactive"
level3_val19="727000"
level3_val20="2601000"
level3_val21="1872000"
level3_val22="65"
level3_val23="18000"
level3_val24="118000"
level3_val25="198000 2184000:178000 2392000:18000"
level3_val26="57 832000:81 936000:17 1040000:85 1144000:97 1248000:72 1352000:94 1456000:89 1560000:60 1664000:57 1768000:82 1872000:98 1976000:99 2184000:96 2392000:70 2496000:61 2600000:91"
level3_val27="20000"
level3_val28="12345678"
level3_val29="0"
level3_val30="0"
level3_val31="712"
level3_val32="736"
level3_val33="712"
level3_val34="128"
level3_val35="0"

# LEVEL 4
# lag percent: 74.7%
# battery life: 134.0%
level4_val1="0"
level4_val2="0"
level4_val3="1"
level4_val4="interactive"
level4_val5="441000"
level4_val6="1587000"
level4_val7="1482000"
level4_val8="73"
level4_val9="38000"
level4_val10="18000"
level4_val11="18000"
level4_val12="41 546000:43 754000:7 858000:6 962000:20 1066000:22 1170000:26 1274000:65 1378000:61 1482000:66 1586000:98"
level4_val13="20000"
level4_val14="12345678"
level4_val15="0"
level4_val16="0"
level4_val17="1"
level4_val18="interactive"
level4_val19="727000"
level4_val20="2601000"
level4_val21="1872000"
level4_val22="65"
level4_val23="18000"
level4_val24="138000"
level4_val25="198000 2184000:178000 2288000:58000 2392000:178000 2496000:138000"
level4_val26="64 832000:53 936000:27 1040000:71 1144000:98 1248000:90 1352000:93 1456000:87 1560000:83 1664000:75 1768000:61 1872000:98 1976000:99 2288000:98 2392000:89 2496000:20 2600000:50"
level4_val27="20000"
level4_val28="12345678"
level4_val29="0"
level4_val30="0"
level4_val31="773"
level4_val32="780"
level4_val33="773"
level4_val34="128"
level4_val35="0"

# LEVEL 5
# lag percent: 99.0%
# battery life: 143.6%
level5_val1="0"
level5_val2="0"
level5_val3="1"
level5_val4="interactive"
level5_val5="441000"
level5_val6="1587000"
level5_val7="1482000"
level5_val8="86"
level5_val9="18000"
level5_val10="38000"
level5_val11="38000"
level5_val12="44 546000:27 754000:36 858000:38 962000:8 1066000:3 1170000:16 1274000:92 1378000:53 1482000:70 1586000:65"
level5_val13="20000"
level5_val14="12345678"
level5_val15="0"
level5_val16="0"
level5_val17="1"
level5_val18="interactive"
level5_val19="727000"
level5_val20="2601000"
level5_val21="1872000"
level5_val22="77"
level5_val23="18000"
level5_val24="58000"
level5_val25="198000 2184000:138000 2288000:58000 2392000:78000"
level5_val26="61 832000:92 936000:83 1040000:95 1144000:91 1248000:81 1352000:96 1456000:87 1560000:77 1664000:80 1768000:58 1872000:99 2288000:97 2392000:40 2496000:42 2600000:72"
level5_val27="20000"
level5_val28="12345678"
level5_val29="0"
level5_val30="0"
level5_val31="643"
level5_val32="927"
level5_val33="643"
level5_val34="128"
level5_val35="0"

# LEVEL 6
# lag percent: 119.7%
# battery life: 150.7%
level6_val1="0"
level6_val2="0"
level6_val3="1"
level6_val4="interactive"
level6_val5="441000"
level6_val6="1587000"
level6_val7="1482000"
level6_val8="82"
level6_val9="18000"
level6_val10="138000"
level6_val11="158000"
level6_val12="30 546000:33 754000:38 962000:16 1066000:26 1170000:12 1274000:95 1378000:66 1482000:83 1586000:63"
level6_val13="20000"
level6_val14="12345678"
level6_val15="0"
level6_val16="0"
level6_val17="1"
level6_val18="interactive"
level6_val19="727000"
level6_val20="2601000"
level6_val21="1872000"
level6_val22="79"
level6_val23="18000"
level6_val24="38000"
level6_val25="198000 2288000:78000 2392000:178000 2496000:78000"
level6_val26="59 832000:93 936000:83 1040000:97 1144000:91 1248000:90 1352000:97 1456000:92 1560000:83 1664000:79 1768000:65 1872000:98 1976000:99 2184000:98 2288000:96 2392000:54 2496000:46 2600000:71"
level6_val27="20000"
level6_val28="12345678"
level6_val29="0"
level6_val30="0"
level6_val31="644"
level6_val32="960"
level6_val33="644"
level6_val34="128"
level6_val35="0"


# global variables
HAS_BAK=0
NOT_MATCH_NUM=0

# $1:value $2:file path
lock_value() 
{
	if [ -f ${2} ]; then
		chmod 0666 ${2}
		echo ${1} > ${2}
		chmod 0444 ${2}
	fi
}

# $1:level_number
apply_level() 
{
	# 0. SELinux permissive
	setenforce 0
    # 1. backup
    backup_default
    # 2. apply modification
    for n in `seq ${PARAM_NUM}`
    do
        eval obj="$"sysfs_obj${n}
        eval val="$"level${1}_val${n}
        lock_value "${val}" ${obj}
    done
    # 3. save current level to file
    echo ${1} > ${CUR_LEVEL_FILE}
}

# $1:value $2:file path
check_value() 
{
    if [ -f ${2} ]; then
        expected="${1}"
        actual="`cat ${2}`"
        if [ "${actual}" != "${expected}" ]; then
            # input_boost_freq has a additional line break
            case1=$(echo "${actual}" | grep "${expected}")
            # Actual scaling_min_freq is 633600, but given is 633000. That's OK
            case2=$(echo "${2}" | grep -E "scaling_m.{2}_freq$")
            # skip msm_performance/parameters: cpu_min_freq and cpu_max_freq
            case3=$(echo "${2}" | grep -E "cpu_m.{2}_freq$")
            if [ "${case1}" == "" ] && [ "${case2}" == "" ] && [ "${case3}" == "" ]; then
                NOT_MATCH_NUM=$(expr ${NOT_MATCH_NUM} + 1)
                echo "[FAIL] ${2}"
                echo "expected: ${expected}"
                echo "actual: ${actual}"
            fi
        fi
    else
        echo "[IGNORE] ${2}"
    fi
}

# $1:level_number
verify_level() 
{
    for n in `seq ${PARAM_NUM}`
    do
        eval obj="$"sysfs_obj${n}
        eval val="$"level${1}_val${n}
        check_value "${val}" ${obj}
    done
    echo "Verified ${PARAM_NUM} parameters, ${NOT_MATCH_NUM} FAIL"
}

backup_default()
{
    if [ ${HAS_BAK} -eq 0 ]; then
        # clear previous backup file
        echo "" > ${PARAM_BAK_FILE}
        for n in `seq ${PARAM_NUM}`
        do
            eval obj="$"sysfs_obj${n}
            echo "bak_obj${n}=${obj}" >> ${PARAM_BAK_FILE}
            echo "bak_val${n}=\"`cat ${obj}`\"" >> ${PARAM_BAK_FILE}
        done
        echo "Backup default parameters has completed."
    else
        echo "Backup file already exists, skip backup."
    fi
}

restore_default()
{
    if [ -f ${PARAM_BAK_FILE} ]; then
        # read backup variables
        while read line
        do
            eval ${line}
        done < ${PARAM_BAK_FILE}
        # set backup variables
        for n in `seq ${PARAM_NUM}`
        do
            eval obj="$"bak_obj${n}
            eval val="$"bak_val${n}
            lock_value "${val}" ${obj}
        done
        echo "Restore OK"
    else
        echo "Backup file for default parameters not found."
        echo "Restore FAIL"
    fi
}

permanently_disable_perfd()
{
    stop perfd
    perfd_path=`which perfd`
    if [ -n "${perfd_path}" ]; then
        mv ${perfd_path} `dirname ${perfd_path}`/perfd_bak
        echo "Perfd has been disabled."
    else
        echo "Perfd binary not found."
    fi
}

permanently_enable_perfd()
{
    perfd_bak_path=`which perfd_bak`
    if [ -n "${perfd_bak_path}" ]; then
        mv ${perfd_bak_path} `dirname ${perfd_bak_path}`/perfd
        echo "Perfd has been enabled."
    else
        echo "Perfd_bak binary not found."
    fi
    start perfd
}

# suppress stderr
(

echo ""

# backup runonce flag
if [ -f ${PARAM_BAK_FILE} ]; then
    HAS_BAK=1
fi

action=$1
# default option is balance
if [ ! -n "$action" ]; then
    action="balance"
fi

if [ "$action" = "debug" ]; then
	echo "Project WIPE v2 https://github.com/yc9559/wipe-v2"
	echo "Author: yc9559"
	echo "Platform: e8890"
	echo "Generated at: 2019-05-25 15:53:51"
	echo ""
    # perform parameter verification
    cur_level=`cat ${CUR_LEVEL_FILE}`
	if [ -n "${cur_level}" ]; then
        echo "Current level: ${cur_level}"
        verify_level ${cur_level}
    else
        echo "Current level: not detected"
    fi
    echo ""
	exit 0
fi

if [ "$action" = "restore" ]; then
	restore_default
    rm ${CUR_LEVEL_FILE}
fi

if [ "$action" = "powersave" ]; then
    echo "Applying powersave..."
    apply_level 5
    echo "Applying powersave done."
fi

if [ "$action" = "balance" ]; then
    echo "Applying balance..."
    apply_level 3
    echo "Applying balance done."
fi

if [ "$action" = "performance" ]; then
    echo "Applying performance..."
    apply_level 1
    echo "Applying performance done."
fi

if [ "$action" = "fast" ]; then
    echo "Applying fast..."
    apply_level 0
    echo "Applying fast done."
fi

if [ "$action" = "level" ]; then
    level=${2}
    if [ "${level}" -ge "0" ] && [ "${level}" -le "6" ]; then
        echo "Applying level ${level}..."
        apply_level ${level}
        echo "Applying level ${level} done."
    else
        echo "Level ${level} not supported."
    fi
fi

if [ "$action" = "perfd" ]; then
    cmd=${2}
    if [ "${cmd}" == "enable" ]; then
        permanently_enable_perfd
    fi
    if [ "${cmd}" == "disable" ]; then
        permanently_disable_perfd
    fi
fi

echo ""

# suppress stderr
) 2>/dev/null

exit 0
